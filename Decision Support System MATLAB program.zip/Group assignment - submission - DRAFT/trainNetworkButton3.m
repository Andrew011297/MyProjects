function [net,mse, accuracy] = trainNetworkButton3(train_input, train_output, test_input,test_output)

%% Create the network
%network parameters are defined
net = feedforwardnet(15, 'trainbr');
%the network is configured with the training inputs and outputs prepared
%earlier in the program
net = configure(net, train_input, train_output);
%% Train the network
%the network is trained
net = train(net, train_input, train_output); 
%view(net);

%% The model saves the network, mean squared error and accuracy figures for loading later

%a mean squared error value is produced based upon  the predicted
%test_outputs and the actual test outputs - this is reported to the user
y = net(test_input);
mse = perform(net, test_output,y);

%the model makes predictions on the test_input to generate its own
%test_output
predictions = sim(net, test_input);
%the difference between the predicted outputs and the actuals is calculated
predictions_divide_actuals = rdivide(predictions, test_output);
%this can then be reported as an accuracy figure to the user
accuracy_sum = sum(predictions_divide_actuals);
accuracy = (accuracy_sum/7)*100;

%the numbers are saved to be loaded in where necessary in case the user
%decides to use the saved model
save accuracy
save mse
save net 
end


