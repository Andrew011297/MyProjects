%% clearvars works better for updating the UI properly
clearvars;
clc;
%% Can use this to suppress warnings from the command line.
warning('off' , 'all')
%%Trying something
format bank
%% Should check to see if the model has been saved - remove out to function
%if the model has not been saved then proceed through programme
if isfile('net.mat')
    fprintf("There is already a trained network in the directory.\n");
    %need to expand this now - we only need to do certain things if the
    %file does not exist
    answer = questdlg("Would you like to use the network that already exists?", "Pre-existing network found", "Yes", "No", "No");
    switch answer
        case "Yes"
            useNet = 1;
            load('accuracy.mat');
            load('net.mat');
            
            %doing this doesnt work - it loads all the tables separately?
            %not as one big one
            load('dataTable.mat');
            
            fprintf("Net and dataTable loaded in.");
            %now we need to load the net in - we can use this variable to
            %skip all the datatable creation and head straight to testing
        case "No"
            useNet =0;
            makeNet =1;
            %carry on with making a new network and training it
    end
    %not sure if i need to do this?
    network_var = 1;
else
    fprintf("There is no trained network in the directory.\n");
    %carry on as usual then
    network_var = 2;
    useNet =0;
end
%% Read in the appropriate csv files 
dataTable = createData();
%% Use the function to generate appropriate datasets
[output,train_input, train_output, test_input, test_output] = prepareData(dataTable);
%% GUI
%Set up the window
fig = uifigure('Name','European DSS - 2016 Data','Position', [100 100 500 315]);
%Use a grid to layout the GUI
grid1 = uigridlayout(fig, [1,2]);
grid1.ColumnWidth = {220,'2x'};
grid1.RowHeight = {500,500,500};
%grid1.RowHeight = {300,300,300};
%Add the first panel to the GUI
p = uipanel(grid1,'Title','Interact');
%Grid in the panel
grid2 = uigridlayout(p,[3 2]);
grid2.RowHeight = {22,22,22};
grid2.ColumnWidth = {80,'1x'};
%Train model label
tmlabel = uilabel(grid2);
tmlabel.HorizontalAlignment = 'right';
tmlabel.Text = 'Model status:';
%Report the status of the model through use of a label
mslabel = uilabel(grid2);
mslabel.HorizontalAlignment = 'right';
mslabel.Text = "Model untrained.";
%A random label
ratelabel = uilabel(grid2);
ratelabel.HorizontalAlignment = 'right';
ratelabel.Text = 'Something:';
outputlabel = uilabel(grid2);
outputlabel.HorizontalAlignment = 'right';
%edit field
ef = uieditfield(grid2, 'ValueChangedFcn',@(ef,event)textChanged(ef,outputlabel));
%% The model is only trained if it needs to be 
%reduces computation load 
if useNet ==1
    mslabel.Text = "Model loaded.";
    view(net);
else
    %so you can return the accuracy when you dont update the label in the
    %function?
    %[mslabel, net, accuracy] = trainNetworkButton2(mslabel, train_input,
    %train_output);
   [net,accuracy] = trainNetworkButton2(train_input, train_output, test_input, test_output);
    mslabel.Text = "Model trained.";
end


%% Add the table to the GUI
table = uitable(grid1);
table.Data = dataTable;
table.RowName = 'numbered';
%this line doesnt work in matlab 2018b? works in uni though
%table.ColumnSortable = true;

%% Add the second panel to the GUI
p2 = uipanel(grid1,'Title','Output');
grid3 = uigridlayout(p2, [3 2]);
grid3.RowHeight = {22,22,22};
grid3.ColumnWidth = {100,'1x'};
%add a label
lbl_model_accuracy =uilabel(grid3);
lbl_model_accuracy.HorizontalAlignment = 'right';
lbl_model_accuracy.Text = 'Model accuracy: ';


accuracy_string = num2str(accuracy);
lbl_model_accuracy_value = uilabel(grid3);
lbl_model_accuracy_value.HorizontalAlignment = 'right';
lbl_model_accuracy_value.Text = accuracy_string;

lbl_happ_test=  uilabel(grid3);
lbl_happ_test.HorizontalAlignment=  'right';
lbl_happ_test.Text = "Result: ";

lbl_happ_test2 = uilabel(grid3);
lbl_happ_test2.HorizontalAlignment='right';
lbl_happ_test2.Text = "Empty";

lbl_input_1 = uilabel(grid3);
lbl_input_1.HorizontalAlignment='right';
lbl_input_1.Text = "Avg hours worked: ";
%see if we can generate these dynamically from the table?
input_1 = uieditfield(grid3,'numeric','Limits',[32 47]);

lbl_input_2 = uilabel(grid3);
lbl_input_2.HorizontalAlignment='right';
lbl_input_2.Text= "Avg life exp.: ";
input_2 = uieditfield(grid3,'numeric','Limits',[75 84]);

lbl_input_3 = uilabel(grid3);
lbl_input_3.HorizontalAlignment='right';
lbl_input_3.Text="GDP:";
input_3 = uieditfield(grid3,'numeric','Limits',[10000 3159750]);

result_label = uilabel(grid3);
result_label.HorizontalAlignment="right";
result_label.Text="Click";
testButton=uibutton(grid3,'Text', 'Test', 'ButtonPushedFcn',@(testButton,event) testButtonPushed(testButton, input_1, input_2, input_3, lbl_happ_test2, net));



% result_txt_label = uilabel(grid3);
% result_txt_label.HorizontalAlignment="right";
% result_txt_label.Text = "Result: ";
% 
% happiness_score_label = uilabel(grid3);
% happiness_score_label.HorizontalAlignment= "right";
% happiness_score_label.Text = "Empty";

%% Add a graph to show happiness data below the table
ax = uiaxes(grid1);
ax.Title.String = "Country Happiness Scores 2016";
ax.XLabel.String = "Country";
ax.Color = "none";
ax.YLabel.String = "2016 Happiness Score";
y = dataTable.HappinessScore;
x= categorical(dataTable.Country);
bar(ax,x,y);
%trying to get the values from the button push in order to test the network
function result = testButtonPushed(testButton, input_1, input_2, input_3, lbl_happ_test2, net)
result="Hello";
input_val_1 = input_1.Value;
input_val_2 = input_2.Value;
input_val_3 = input_3.Value;
disp(input_val_1);
disp(input_val_2);
disp(input_val_3);

%needs to be avghours, gdp, avg life exp
yellow = [input_val_1, input_val_3, input_val_2];
yellow
yeet = yellow'
test_out = sim(net, yeet);
result = test_out;

disp(result);
result = num2str(result);
%need to test the network in here - probably concatenate the inputs
%together into one matrix, order is important
lbl_happ_test2.Text = result;

testButton.Text = "Tested";
end
function textChanged(ef,outputlabel)
outputlabel.Text = ef.Value;
disp(ef.Value);
end