%% KF7009 - Decision Support Systems
%MSc Advanced Computer Science, Northumbria University 
% 2019/2020
% Assignment 2

%Group members:
%Andrew Robson: w16011147
%Lauren Scott: w16005137
%Thomas Every: w15007297
function dataTable = createData()
%Read in and join the tables together for use in the program
%% Read in the CSV files as tables
fprintf("Reading in CSV files...\n");
f = waitbar(0,'Name', "Preparing data", "Please wait...");
world_2016 = readtable("datasets/world-happiness/2016.csv");
waitbar(0.083, f, "Please wait...");
europe_workhours_2016 = readtable("datasets/europe_datasets/work_hours_2016.csv");
waitbar(0.166, f, "Please wait...");
europe_crime_2016 = readtable("datasets/europe_datasets/crime_2016.csv");
waitbar(0.249, f, "Please wait...");
europe_pollution_2016 = readtable("datasets/europe_datasets/pollution_2016.csv");
waitbar(0.332, f, "Please wait...");
europe_gdp_2016 = readtable("datasets/europe_datasets/gdp_2016.csv");
waitbar(0.415, f, "Please wait...");
europe_life_exp_2016 = readtable("datasets/europe_datasets/life_expectancy_2016.csv");
waitbar(0.50, f, "Files read in.");
fprintf("CSV file input complete.\n");
%% Join the tables together - strip out some unnecessary data
fprintf("Joining data tables together...\n");
testTable = innerjoin(world_2016,europe_workhours_2016);
waitbar(0.60, f, "Joining tables...");
testTable.Region=[]; %not needed as all the countries are european
testTable = innerjoin(testTable, europe_crime_2016);
waitbar(0.70, f, "Joining tables...");
testTable = innerjoin(testTable, europe_pollution_2016);
waitbar(0.80, f, "Joining tables...");
testTable = innerjoin(testTable, europe_gdp_2016);
waitbar(0.90, f, "Joining tables...");
testTable = innerjoin(testTable, europe_life_exp_2016);
waitbar(1.0, f, "Table joins complete.");
fprintf("Table joins successful.\n");
close(f)

%% Return the dataTable to be used
dataTable = testTable;
%% Save the datatable 
%doesnt work?
%this will assist in reducing computational load 
save dataTable;
end

