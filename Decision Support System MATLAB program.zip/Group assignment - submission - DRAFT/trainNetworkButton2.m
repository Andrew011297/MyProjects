function [net,accuracy] = trainNetworkButton2(train_input, train_output, test_input,test_output)

%% Create the network
%need to play around with parameters
net = feedforwardnet(10);
net = configure(net, train_input, train_output);
%% Train the network
net = train(net, train_input, train_output); %can we supress the ui output window?
%update the UI to inform the user
%mslabel.Text = "Model trained.";
%% need to test the network in here as well - could return an accuracy figure 
%do some testing
view(net);
%okay so this doesnt work
%accuracy = perform(net, test_input, test_output);
%accuracy = 55;

%% A set of outputs can be produced from the network using the test_input

%outputs = sim(net, test_input);
%outputs can then be compared against test_output?

%% The model saves the network and accuracy figures for loading later

%% Testing something - the model's performance is measured against the training_outputs
%change this to test against the test data
y = net(train_input);
accuracy = perform(net, train_output,y);
save accuracy
save net 
end


