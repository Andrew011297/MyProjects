function [tm,yeet] = trainNetworkButton(tm, train_input, train_output)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
tm.Text = "Model trained";

%yeet = createNet(train_input, train_output);
% net = feedforwardnet(10);
% net = configure(net, train_input, train_output);
% net = train(net, train_input, train_output);
% fprintf("Button pushed test.\n");
% confirmation_message =msgbox("The model has been trained", "Success");

%% Trying something else
yeet = feedforwardnet(10);
yeet = configure(yeet, train_input, train_output);
yeet = train(yeet, train_input, train_output);

end

function yeet = createNet(train_input, train_output)

yeet = feedforwardnet(10);
yeet = configure(yeet, train_input, train_output);
yeet = train(yeet, train_input, train_output);
%fprintf("Button pushed test.\n");
%confirmation_message =msgbox("The model has been trained", "Success");
end
