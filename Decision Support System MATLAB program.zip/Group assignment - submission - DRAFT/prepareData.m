%% KF7009 - Decision Support Systems
%MSc Advanced Computer Science, Northumbria University 
% 2019/2020
% Assignment 2

%Group members:
%Andrew Robson: w16011147
%Lauren Scott: w16005137
%Thomas Every: w15007297
function [output,train_input, train_output, test_input, test_output] = prepareData(dataTable)

output = dataTable.HappinessScore;
input = removevars(dataTable,{'Country', 'HappinessScore', 'HappinessRank', 'LowerConfidenceInterval','UpperConfidenceInterval', 'Economy_GDPPerCapita_','Family','Health_LifeExpectancy_','Freedom','Trust_GovernmentCorruption_','Generosity','DystopiaResidual','prct_rpt_crime','prct_rpt_pollution'});
%the below is the data split - 80%
PD=0.80;
%generate training input and outputs
train_input = input(1:round(PD*length(output)),:);
train_input = train_input{:,:};
train_input = train_input';
train_output = output(1:round(PD*length(output)));
train_output = train_output';
%generate testing input and outputs
test_input = input(round(PD*length(output)):end,:);
test_input = test_input{:,:};
test_input = test_input';
test_output = output(round(PD*length(output)):end);
test_output = test_output';
end

