%% KF7009 - Decision Support Systems
%MSc Advanced Computer Science, Northumbria University 
% 2019/2020
% Assignment 2

%Group members:
%Andrew Robson: w16011147
%Lauren Scott: w16005137
%Thomas Every: w15007297
%% Clear the workspace and the console 
%clearvars works better for updating the UI properly
clearvars;
clc;
%% Can use this to suppress warnings from the command line.
warning('off' , 'all')
format bank
%% Check to see if the model has been saved 
%if the model has not been saved then proceed through programme
if isfile('net.mat')
    fprintf("There is already a trained network in the directory.\n");
    answer = questdlg("Would you like to use the network that already exists?", "Pre-existing network found", "Yes", "No", "No");
    switch answer
        case "Yes"
            useNet = 1;
            load('mse.mat');
            load('net.mat');
            load('accuracy.mat');
            %doing this doesnt work - it loads all the tables separately?
            %load('dataTable.mat');
            fprintf("Net loaded in.");
            %now we need to load the net in - we can use this variable to
            %skip all the datatable creation and head straight to testing
        case "No"
            useNet =0;
            %makeNet =1;
            
    end
    %not sure if i need to do this?
    network_var = 1;
else
    fprintf("There is no trained network in the directory.\n");
    %carry on as usual then
    network_var = 2;
    useNet =0;
end

%% Read in the appropriate csv files 
try
    dataTable = createData();
catch
    f=errordlg("Dataset could not be created.","Program error");
end
%% Use the function to generate appropriate datasets
try
    [output,train_input, train_output, test_input, test_output] = prepareData(dataTable);
catch
    f=errordlg("Dataset could not be prepared.","Program error");
end


%% GUI
%Set up the window
fig = uifigure('Name','European DSS - 2016 Data','Position', [100 100 500 315]);
%Use a grid to layout the GUI
grid1 = uigridlayout(fig, [1,2]);
grid1.ColumnWidth = {220,'2x'};
grid1.RowHeight = {500,500,500};
%grid1.RowHeight = {300,300,300};
%Add the first panel to the GUI
p = uipanel(grid1,'Title','Interact');
%Grid in the panel
grid2 = uigridlayout(p,[3 2]);
grid2.RowHeight = {22,22,22};
grid2.ColumnWidth = {80,'1x'};
%Train model label
tmlabel = uilabel(grid2);
tmlabel.HorizontalAlignment = 'right';
tmlabel.Text = 'Model status:';
%Report the status of the model through use of a label
mslabel = uilabel(grid2);
mslabel.HorizontalAlignment = 'right';
mslabel.Text = "Model untrained.";
%A label
% ratelabel = uilabel(grid2);
% ratelabel.HorizontalAlignment = 'right';
% ratelabel.Text = 'Something:';
% outputlabel = uilabel(grid2);
% outputlabel.HorizontalAlignment = 'right';
% %edit field
% ef = uieditfield(grid2, 'ValueChangedFcn',@(ef,event)textChanged(ef,outputlabel));
%% The model is only trained if it needs to be
%reduces computational load 
if useNet ==1
    fprintf("The network will be used - no need to prep data.\n");
    mslabel.Text = "Model loaded.";
    view(net);%maybe get rid of this lauren doesnt like it
else
    try
    [net,mse, accuracy] = trainNetworkButton3(train_input, train_output, test_input, test_output);
    mslabel.Text = "Model trained.";
    catch
    f=errordlg("The model could not be trained.","Program error");
    end
end
%% Add the table to the GUI
table = uitable(grid1);
table.Data = dataTable;
table.RowName = 'numbered';
%column sortable is a 2019a/b option only
table.ColumnSortable = true;
%% Add the second panel to the GUI
p2 = uipanel(grid1,'Title','Output');
grid3 = uigridlayout(p2, [3 2]);
grid3.RowHeight = {22,22,22};
grid3.ColumnWidth = {100,'1x'};
%add a label
lbl_model_mse =uilabel(grid3);
lbl_model_mse.HorizontalAlignment = 'right';
lbl_model_mse.Text = 'Model MSE: ';
mse_string = num2str(mse);
lbl_model_accuracy_value = uilabel(grid3);
lbl_model_accuracy_value.HorizontalAlignment = 'right';
lbl_model_accuracy_value.Text = mse_string;

lbl_model_accuracy = uilabel(grid3);
lbl_model_accuracy.HorizontalAlignment = 'right';
lbl_model_accuracy.Text = 'Accuracy(%): ';
accuracy_string = num2str(accuracy);
lbl_model_accuracy_value = uilabel(grid3);
lbl_model_accuracy_value.HorizontalAlignment = 'right';
lbl_model_accuracy_value.Text = accuracy_string;

lbl_happ_test=  uilabel(grid3);
lbl_happ_test.HorizontalAlignment=  'right';
lbl_happ_test.Text = "Result: ";
lbl_happ_test2 = uilabel(grid3);
lbl_happ_test2.HorizontalAlignment='right';
lbl_happ_test2.Text = "Empty";
lbl_input_1 = uilabel(grid3);
lbl_input_1.HorizontalAlignment='right';
lbl_input_1.Text = "Avg hours worked: ";
%see if we can generate these dynamically from the table?
input_1 = uieditfield(grid3,'numeric','Limits',[32 47]);
lbl_input_2 = uilabel(grid3);
lbl_input_2.HorizontalAlignment='right';
lbl_input_2.Text= "Avg life exp.: ";
%ef = uieditfield(grid2, 'ValueChangedFcn',@(ef,event)textChanged(ef,outputlabel));
input_2 = uieditfield(grid3,'numeric','Limits',[75 84]);
lbl_input_3 = uilabel(grid3);
lbl_input_3.HorizontalAlignment='right';
lbl_input_3_text = "Gross Domestic";
lbl_input_3.Text=lbl_input_3_text + newline + "Product:";
input_3 = uieditfield(grid3,'numeric','Limits',[10000 3159750]);
result_label = uilabel(grid3);
result_label.HorizontalAlignment="right";
result_label.Text="Click";

testButton=uibutton(grid3,'Text', 'Test', 'ButtonPushedFcn',@(testButton,event) testButtonPushed(testButton, input_1, input_2, input_3, lbl_happ_test2, net));


%% Add a graph to show happiness data below the table
ax = uiaxes(grid1);
ax.Title.String = "Country Happiness Scores 2016";
ax.XLabel.String = "Country";
ax.Color = "none";
ax.YLabel.String = "2016 Happiness Score";
y = dataTable.HappinessScore;
x= categorical(dataTable.Country);
bar(ax,x,y);
%trying to get the values from the button push in order to test the network
function result = testButtonPushed(testButton, input_1, input_2, input_3, lbl_happ_test2, net)
input_val_1 = input_1.Value;
input_val_2 = input_2.Value;
input_val_3 = input_3.Value;
%disp(input_val_1);
%disp(input_val_2);
%disp(input_val_3);

%User inputs are provided to a matrix in the correct order
user_test_input = [input_val_1, input_val_3, input_val_2];
%the matrix is transposed in order to be fed to the network
user_test_input = user_test_input';
%the network is tested against the user provided values
user_test_out = sim(net, user_test_input);
result = user_test_out;
disp(result);
result = num2str(result);
lbl_happ_test2.Text = result;
testButton.Text = "Tested";
end
%can get rid of this
function textChanged(ef,outputlabel)
outputlabel.Text = ef.Value;
disp(ef.Value);
end