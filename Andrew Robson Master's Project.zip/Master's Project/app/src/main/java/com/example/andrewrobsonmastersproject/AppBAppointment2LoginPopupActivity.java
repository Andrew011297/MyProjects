/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.TextView;

//Class holds functionality for creating the activity and button links
public class AppBAppointment2LoginPopupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_appointment2_login_popup);

        //variables to get the dimensions of the user's phone screen
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        //converting to width and height
        int width = dm.widthPixels;
        int height = dm.heightPixels;

        //Creating the popup to be smaller than the prior activity
        getWindow().setLayout((int)(width*1.6),(int) (height*.4));
    }

    //Toggles the visibility of error text to the user
    public void AppBAppointment2PopupConfirmButton(View view)
    {
        TextView text = (TextView) findViewById(R.id.textView154);
        text.setVisibility(view.VISIBLE);
    }

    //Closes the popup
    public void AppBAppointment2PopupCancelButton(View view)
    {
        AppBAppointment2LoginPopupActivity.this.finish();
    }
}