/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

//Class holds functionality for creating the activity and button links
public class AppACreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_create_account);

        //Makes the application pause for 1.5 seconds (artificial load time)
        try
        {
            Thread.sleep(1500);
        }
        catch (InterruptedException e) {}
    }

    //Method puts all of the checkboxes and text fields into variables then checks to see
    //if they have been filled and that only one checkbox has been ticked
    //If requirements are met, the user is sent through
    public void AppACreateAccountSubmitButton(View view)
    {
        //Checkbox variables
        CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);

        //Text field variables
        EditText name = (EditText) findViewById(R.id.editTextTextPersonName13);
        String sname = name.getText().toString();
        EditText dob = (EditText) findViewById(R.id.editTextDate);
        String sdob = dob.getText().toString();
        EditText phone = (EditText) findViewById(R.id.editTextNumber);
        String sphone = phone.getText().toString();
        EditText address1 = (EditText) findViewById(R.id.editTextTextPersonName14);
        String saddress1 = address1.getText().toString();
        EditText address2 = (EditText) findViewById(R.id.editTextTextPersonName15);
        String saddress2 = address2.getText().toString();
        EditText address3 = (EditText) findViewById(R.id.editTextTextPersonName16);
        String saddress3 = address3.getText().toString();
        EditText email = (EditText) findViewById(R.id.editTextTextEmailAddress2);
        String semail = email.getText().toString();
        EditText password = (EditText) findViewById(R.id.editTextTextPassword2);
        String spassword = password.getText().toString();

        //If statement to check if all text fields are not empty
        if(sname.matches("") || sdob.matches("") || sphone.matches("") || saddress1.matches("") || saddress2.matches("") || saddress3.matches("") || semail.matches("") || spassword.matches(""))
        {
            //Display message to the user
            Toast.makeText(this, "Incorrect.", Toast.LENGTH_SHORT).show();
        }
        //Check if both checkboxes are ticked
        else if(checkBox.isChecked() && checkBox2.isChecked())
        {
            //Display message to the user
            Toast.makeText(getApplicationContext(),"Incorrect.", Toast.LENGTH_SHORT).show();
        }
        //Check that one checkbox has been ticked
        else if(checkBox.isChecked() || checkBox2.isChecked())
        {
            //Send user to appointment 4 activity
            Intent startNewActivity = new Intent(AppACreateAccountActivity.this, AppAAppointment4Activity.class);
            startActivity(startNewActivity);
        }
    }
}