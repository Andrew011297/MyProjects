/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    //Button variable
    private Button AppAButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupHyperLink();

        //Creating button variable and applying an on click listener to it
        AppAButton = (Button) findViewById(R.id.App_A_Button);
        AppAButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                AppAButtonSend(view);
            }
        });

    }

    //Sets up the hyper link to the questionnaire
    private void setupHyperLink()
    {
        TextView linkTextView = findViewById(R.id.Questionnaire_Link);
        linkTextView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    //Sends the user to the app A scenario page
    public void AppAButtonSend(View view)
    {
        Intent startNewActivity = new Intent(MainActivity.this, AppAScenario_Activity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the app B scenario page
    public void AppBButtonSend(View view)
    {
        Intent startNewActivity = new Intent(MainActivity.this, AppBScenarioActivity.class);
        startActivity(startNewActivity);
    }
}