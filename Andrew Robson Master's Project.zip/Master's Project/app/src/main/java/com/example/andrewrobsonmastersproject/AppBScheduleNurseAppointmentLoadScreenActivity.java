/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

//Class holds functionality for creating the activity and button links
public class AppBScheduleNurseAppointmentLoadScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_schedule_nurse_appointment_load_screen);

        //Button variable cast to corresponding .xml document
        final Button button1 = (Button) findViewById(R.id.button60);

        //Makes the application pause for 1.5 seconds (artificial load time)
        //Using handler ensures that the load page actually shows on the user's screen before
        //loading the next page
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                button1.performClick();
            }
        }, 1500);
    }

    //button which the application automatically triggers to send the user to the schedule nurse appointment page
    public void AppBNurseVisitationSkipButton(View view)
    {
        Intent startNewActivity = new Intent(AppBScheduleNurseAppointmentLoadScreenActivity.this, AppBScheduleNurseAppointmentActivity.class);
        startActivity(startNewActivity);
    }
}