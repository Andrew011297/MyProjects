/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppAMainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_main_menu);

        //Makes the application pause for 3 seconds (artificial load time)
        //calls the popup class to begin
        try
        {
            Thread.sleep(3000);
            startActivity(new Intent(AppAMainMenuActivity.this,AppAPopup.class));

        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the about us page
    public void AboutUsButton(View view)
    {
        Intent startNewActivity = new Intent(AppAMainMenuActivity.this, AppAAboutUsActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void AppAJoinThePracticeButton(View view)
    {
        Intent startNewActivity = new Intent(AppAMainMenuActivity.this, AppAUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the appointment 1 page
    public void MakeAnAppointmentButton(View view)
    {
        Intent startNewActivity = new Intent(AppAMainMenuActivity.this, AppAAppointment1.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void AppAWhoElseCanHelpButton(View view)
    {
        Intent startNewActivity = new Intent(AppAMainMenuActivity.this, AppAUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the need help page
    public void AppANeedHelpButton(View view)
    {
        Intent startNewActivity = new Intent(AppAMainMenuActivity.this, AppANeedHelpActivity.class);
        startActivity(startNewActivity);
    }
}