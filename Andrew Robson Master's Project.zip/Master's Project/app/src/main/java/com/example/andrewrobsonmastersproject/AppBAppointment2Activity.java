/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBAppointment2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_appointment2);

        //Makes the application pause for half a second (artificial load time)
        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the create account page
    public void AppBAppointment2CreateAccountButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment2Activity.this, AppBCreateAccountActivity.class);
        startActivity(startNewActivity);
    }

    //Causes the login popup to appear on the page
    public void AppBAppointment2LoginButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment2Activity.this, AppBAppointment2LoginPopupActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the main menu loading page
    public void AppBAppointment2MainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment2Activity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }
}