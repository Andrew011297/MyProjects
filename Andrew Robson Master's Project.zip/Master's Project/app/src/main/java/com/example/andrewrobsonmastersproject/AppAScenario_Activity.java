/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.TextView;

//Class holds functionality for creating the activity and button links
public class AppAScenario_Activity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_scenario_);
    }

    //Sends the user to the main menu page
    public void AppAButtonBegin(View view)
    {
        Intent startNewActivity = new Intent(AppAScenario_Activity.this, AppAMainMenuActivity.class);
        startActivity(startNewActivity);
    }
}
