/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBScenarioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_scenario);
    }

    //Sends the user to the main menu load screen
    public void AppBScenarioButton(View view)
    {
        Intent startNewActivity = new Intent(AppBScenarioActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }
}