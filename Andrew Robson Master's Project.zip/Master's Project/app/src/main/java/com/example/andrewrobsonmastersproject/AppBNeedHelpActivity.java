/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBNeedHelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_need_help);

        //Makes the application pause for half a second (artificial load time)
        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the unavailable page
    public void AppBOnlineSupportButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNeedHelpActivity.this, AppBUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void AppBCareNavigatorButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNeedHelpActivity.this, AppBUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void AppBEmergencyCareButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNeedHelpActivity.this, AppBUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the nurse visitation page
    public void AppBNurseVisitationButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNeedHelpActivity.this, AppBNurseVisitationActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the main menu load screen
    public void AppBNeedHelpMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNeedHelpActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }
}