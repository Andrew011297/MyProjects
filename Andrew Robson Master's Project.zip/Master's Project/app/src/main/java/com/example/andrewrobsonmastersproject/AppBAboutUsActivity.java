/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBAboutUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_about_us);

        //Makes the application pause for half a second (artificial load time)
        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the main menu loading screen
    public void AppBMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAboutUsActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }
}