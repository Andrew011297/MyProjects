/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBMainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_main_menu);

        //Makes the application pause for 2 seconds (artificial load time)
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the about us page
    public void AppBAboutUsButton(View view)
    {
        Intent startNewActivity = new Intent(AppBMainMenuActivity.this, AppBAboutUsActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the appointment page
    public void AppBAppointmentButton(View view)
    {
        Intent startNewActivity = new Intent(AppBMainMenuActivity.this, AppBAppointment1Activity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the need help page
    public void AppBNeedHelpButton(View view)
    {
        Intent startNewActivity = new Intent(AppBMainMenuActivity.this, AppBNeedHelpActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void AppBWhoElseCanHelpButton(View view)
    {
        Intent startNewActivity = new Intent(AppBMainMenuActivity.this, AppBUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void AppBJoinThePracticeButton(View view)
    {
        Intent startNewActivity = new Intent(AppBMainMenuActivity.this, AppBUnavailableActivity.class);
        startActivity(startNewActivity);
    }

}