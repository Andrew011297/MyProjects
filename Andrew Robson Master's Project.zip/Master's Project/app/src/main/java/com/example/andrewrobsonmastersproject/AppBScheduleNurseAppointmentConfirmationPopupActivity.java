/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBScheduleNurseAppointmentConfirmationPopupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_schedule_nurse_appointment_confirmation_popup);

        //variables to get the dimensions of the user's phone screen
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        //converting to width and height
        int width = dm.widthPixels;
        int height = dm.heightPixels;

        //Creating the popup to be smaller than the prior activity
        getWindow().setLayout((int)(width*1.5),(int) (height*.15));
    }

    //Sends the user to the congratulations page
    public void AppBNurseAppointmentConfirmButton(View view)
    {
        Intent startNewActivity = new Intent(AppBScheduleNurseAppointmentConfirmationPopupActivity.this, AppBCongratulationsActivity.class);
        startActivity(startNewActivity);
    }

    //Closes the popup
    public void AppBNurseAppointmentCancelButton(View view)
    {
        AppBScheduleNurseAppointmentConfirmationPopupActivity.this.finish();
    }
}