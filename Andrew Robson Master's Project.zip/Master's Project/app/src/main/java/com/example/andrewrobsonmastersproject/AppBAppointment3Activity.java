/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBAppointment3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_appointment3);

        //Makes the application pause for 2 seconds (artificial load time)
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the task unfinished page
    public void AppBAppointment3NextAvailableAppointmentButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment3Activity.this, AppBTaskUnfinishedActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the schedule appointment load screen
    public void AppBAppointment3ScheduleAnAppointmentButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment3Activity.this, AppBScheduleAppointmentLoadScreenActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the main menu load screen
    public void AppBAppointment3MainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment3Activity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }
}