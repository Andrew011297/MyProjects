/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

//Class holds functionality for creating the activity and button links
public class AppBScheduleAppointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_schedule_appointment);

        //Makes the application pause for 2 seconds (artificial load time)
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the main menu load screen
    public void AppBScheduleAppointmentMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBScheduleAppointmentActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }

    //Method puts all of the checkboxes and text fields into variables then checks to see
    //if they have been filled
    //If requirements are met, the user is sent through
    public void AppBScheduleAppointmentSubmitButton(View view)
    {
        //Text field variables
        EditText date = (EditText) findViewById(R.id.editTextDate6);
        String sdate = date.getText().toString();
        EditText time = (EditText) findViewById(R.id.editTextTime3);
        String stime = time.getText().toString();

        //If statement to check if all text fields are not empty
        if(sdate.matches("") || stime.matches(""))
        {
            //Display message to the user
            Toast.makeText(this, "Please provide a date and time.", Toast.LENGTH_SHORT).show();
        }
        else {
            //opens up the confirmation popup
            Intent startNewActivity = new Intent(AppBScheduleAppointmentActivity.this, AppBScheduleAppointmentConfirmationPopupActivity.class);
            startActivity(startNewActivity);
        }
    }
}