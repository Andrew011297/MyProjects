/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

//Class holds functionality for creating the activity and button links
public class AppBScheduleNurseAppointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_schedule_nurse_appointment);

        //Makes the application pause for 2 seconds (artificial load time)
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the main menu load screen
    public void AppBNurseAppointmentMainMenu(View view)
    {
        Intent startNewActivity = new Intent(AppBScheduleNurseAppointmentActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }

    //Method puts all of the checkboxes and text fields into variables then checks to see
    //if they have been filled
    //If requirements are met, the user is sent through
    public void AppBNurseAppointmentSubmit(View view)
    {
        //Text field variables
        EditText date = (EditText) findViewById(R.id.editTextDate3);
        String sdate = date.getText().toString();
        EditText time = (EditText) findViewById(R.id.editTextTime2);
        String stime = time.getText().toString();
        EditText street = (EditText) findViewById(R.id.editTextTextPersonName21);
        String sstreet = street.getText().toString();
        EditText city = (EditText) findViewById(R.id.editTextTextPersonName22);
        String scity = city.getText().toString();
        EditText postcode = (EditText) findViewById(R.id.editTextTextPersonName23);
        String spostcode = postcode.getText().toString();
        EditText phone = (EditText) findViewById(R.id.editTextPhone3);
        String sphone = phone.getText().toString();
        EditText email = (EditText) findViewById(R.id.editTextTextEmailAddress6);
        String semail = email.getText().toString();

        //If statement to check if all text fields are not empty
        if(sdate.matches("") || stime.matches("") || sstreet.matches("") || scity.matches("") || spostcode.matches("") || sphone.matches("") || semail.matches(""))
        {
            //Display message to the user
            Toast.makeText(this, "Please fill in every field.", Toast.LENGTH_SHORT).show();
        }
        else {
            //Opens the confirmation popup
            Intent startNewActivity = new Intent(AppBScheduleNurseAppointmentActivity.this, AppBScheduleNurseAppointmentConfirmationPopupActivity.class);
            startActivity(startNewActivity);
        }
    }
}