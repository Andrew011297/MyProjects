/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppAAppointment3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_appointment3);

        //Makes the application pause for 1.5 seconds (artificial load time)
        try
        {
            Thread.sleep(1500);
        }
        catch (InterruptedException e){}
    }

    //Calls the popup to begin
    public void AppAAppointmentLogin(View view)
    {
        startActivity(new Intent(AppAAppointment3.this,AppALoginPopupActivity.class));
    }

    //Links button to the create account activity
    public void AppACreateAccountButton(View view)
    {
        Intent startNewActivity = new Intent(AppAAppointment3.this, AppACreateAccountActivity.class);
        startActivity(startNewActivity);
    }
}