/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class MentalHealthActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mental_health);

        //Makes the application pause for 1.5 seconds (artificial load time)
        try
        {
            Thread.sleep(1500);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the main menu page
    public void BackButton(View view)
    {
        Intent startNewActivity = new Intent(MentalHealthActivity.this, AppAMainMenuActivity.class);
        startActivity(startNewActivity);
    }
}