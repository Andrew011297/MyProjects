/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

//Class holds functionality for creating the activity and button links
public class AppBCreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_create_account);

        //Makes the application pause for half a second (artificial load time)
        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the main menu load screen
    public void AppBCreateAccountMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBCreateAccountActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }

    //Method puts all of the checkboxes and text fields into variables then checks to see
    //if they have been filled and that only one checkbox has been ticked
    //If requirements are met, the user is sent through
    public void AppBCreateAccountSubmitButton(View view)
    {
        //Checkbox variables
        CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox5);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox9);

        //Text field variables
        EditText name = (EditText) findViewById(R.id.editTextTextPersonName26);
        String sname = name.getText().toString();
        EditText surname = (EditText) findViewById(R.id.editTextTextPersonName30);
        String ssurname = surname.getText().toString();
        EditText dob = (EditText) findViewById(R.id.editTextDate5);
        String sdob = dob.getText().toString();
        EditText phone = (EditText) findViewById(R.id.editTextPhone2);
        String sphone = phone.getText().toString();
        EditText address1 = (EditText) findViewById(R.id.editTextTextPersonName31);
        String saddress1 = address1.getText().toString();
        EditText address2 = (EditText) findViewById(R.id.editTextTextPersonName32);
        String saddress2 = address2.getText().toString();
        EditText address3 = (EditText) findViewById(R.id.editTextTextPersonName33);
        String saddress3 = address3.getText().toString();
        EditText email = (EditText) findViewById(R.id.editTextTextEmailAddress5);
        String semail = email.getText().toString();
        EditText password = (EditText) findViewById(R.id.editTextTextPassword5);
        String spassword = password.getText().toString();

        //If statement to check if all text fields are not empty
        if(sname.matches("") || sdob.matches("") || sphone.matches("") || saddress1.matches("") || saddress2.matches("") || saddress3.matches("") || semail.matches("") || spassword.matches("")|| ssurname.matches(""))
        {
            //Display message to the user
            Toast.makeText(this, "Please fill in every field.", Toast.LENGTH_SHORT).show();
        }
        //Check if both checkboxes are ticked
        else if(checkBox.isChecked() && checkBox2.isChecked())
        {
            //Display message to the user
            Toast.makeText(getApplicationContext(),"Please check only one sex.", Toast.LENGTH_SHORT).show();
        }
        //Check that one checkbox has been ticked
        else if (checkBox.isChecked() || checkBox2.isChecked())
        {
            //Send user to appointment 4 activity
            Intent startNewActivity = new Intent(AppBCreateAccountActivity.this, AppBCreateAccountConfirmationPopupActivity.class);
            startActivity(startNewActivity);
        }
    }
}