/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBCongratulationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_congratulations);
    }

    //Sends the user back to the main menu page (outside of 'App B')
    public void AppBCongratulationsMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBCongratulationsActivity.this, MainActivity.class);
        startActivity(startNewActivity);
    }
}