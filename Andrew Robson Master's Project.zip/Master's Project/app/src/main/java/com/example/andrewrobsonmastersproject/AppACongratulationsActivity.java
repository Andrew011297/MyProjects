/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppACongratulationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_congratulations);
    }

    //Takes the user back to the very beginning of the program, outside of 'App a'
    public void AppAMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppACongratulationsActivity.this, MainActivity.class);
        startActivity(startNewActivity);
    }
}