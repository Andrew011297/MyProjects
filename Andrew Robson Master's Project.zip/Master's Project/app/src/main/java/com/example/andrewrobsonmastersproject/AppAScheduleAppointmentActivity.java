/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

//Class holds functionality for creating the activity and button links
public class AppAScheduleAppointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_schedule_appointment);

        //Makes the application pause for 2 seconds (artificial load time)
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Method creates variables and casts text fields from the corresponding .xml file them,
    //then checks to verify they are not empty
    public void AppAScheduleSubmit(View view)
    {
        //Text field variables
        EditText dateOfAppointment = (EditText) findViewById(R.id.editTextDate2);
        String sdateOfAppointment = dateOfAppointment.getText().toString();
        EditText timeOfAppointment = (EditText) findViewById(R.id.editTextTime);
        String stimeOfAppointment = timeOfAppointment.getText().toString();

        //Check to see if text fields have been left empty
        if(sdateOfAppointment.matches("") || stimeOfAppointment.matches(""))
        {
            //Error message that is sent to the user
            Toast.makeText(this, "Incorrect.", Toast.LENGTH_SHORT).show();
        }
        else
        {
            //Sends the user to the congratulations page
            Intent startNewActivity = new Intent(AppAScheduleAppointmentActivity.this, AppACongratulationsActivity.class);
            startActivity(startNewActivity);
        }
    }
}