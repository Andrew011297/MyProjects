/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

//Class holds functionality for creating the activity and button links
public class AppBAppointment3LoadScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_appointment3_load_screen);

        //Button variable cast to corresponding .xml document
        final Button button1 = (Button) findViewById(R.id.button62);

        //Makes the application pause for 1.5 seconds (artificial load time)
        //Using handler ensures that the load page actually shows on the user's screen before
        //loading the next page
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                button1.performClick();
            }
        }, 1500);
    }

    //button which the application automatically triggers to send the user to appointment 3
    public void AppBAppointment3LoadScreenSkipButton(View view)
    {
        Intent startNewActivity = new Intent(AppBAppointment3LoadScreenActivity.this, AppBAppointment3Activity.class);
        startActivity(startNewActivity);
    }
}