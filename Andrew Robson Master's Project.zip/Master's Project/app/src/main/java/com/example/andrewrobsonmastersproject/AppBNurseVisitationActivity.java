/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppBNurseVisitationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_b_nurse_visitation);

        //Makes the application pause for half a second (artificial load time)
        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }
    }

    //Sends the user to the main menu load screen
    public void AppBNurseVisitationMainMenuButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNurseVisitationActivity.this, AppBMainMenuLoadScreenActivity.class);
        startActivity(startNewActivity);
    }

    //Opens up the confirmation popup
    public void AppBNurseVisitationBookAnAppointmentButton(View view)
    {
        Intent startNewActivity = new Intent(AppBNurseVisitationActivity.this, AppBNurseVisitationConfirmationPopupActivity.class);
        startActivity(startNewActivity);
    }
}