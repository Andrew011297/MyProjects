/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;

//Class holds functionality for creating the activity and button links
public class AppAPopup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_app_a_popup);

        //variables to get the dimensions of the user's phone screen
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        //Converting to width and height
        int width = dm.widthPixels;
        int height = dm.heightPixels;

        //Creating the popup to be smaller than the prior activity
        getWindow().setLayout((int)(width*.9),(int) (height*.4));
    }

    //Sends the user to the unavailable page
    public void SickNotesButton(View view)
    {
        Intent startNewActivity = new Intent(AppAPopup.this, AppAUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the unavailable page
    public void DizzinessButton(View view)
    {
        Intent startNewActivity = new Intent(AppAPopup.this, AppAUnavailableActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the mental health page
    public void MentalHealthButton(View view)
    {
        Intent startNewActivity = new Intent(AppAPopup.this, MentalHealthActivity.class);
        startActivity(startNewActivity);
    }

    //Sends the user to the child illness page
    public void ChildIllnessButton(View view)
    {
        Intent startNewActivity = new Intent(AppAPopup.this, AppAChildIllnessActivity.class);
        startActivity(startNewActivity);
    }
}