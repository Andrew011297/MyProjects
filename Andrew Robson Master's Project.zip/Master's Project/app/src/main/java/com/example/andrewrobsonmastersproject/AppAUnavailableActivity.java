/*
    Andrew Robson w16011147
    16/09/2020
    Master's Project
 */

package com.example.andrewrobsonmastersproject;

//Import statements
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

//Class holds functionality for creating the activity and button links
public class AppAUnavailableActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_a_unavailable);

        //Makes the application pause for 4 seconds (artificial load time)
        try
        {
            Thread.sleep(4000);
        }
        catch (InterruptedException e)
        {
        }
    }
}